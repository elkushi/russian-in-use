
  # Russian Language Learning Website

  This is a code bundle for Russian Language Learning Website. The original project is available at https://www.figma.com/design/ZYDlxcC2zBl0o4k66IFgQb/Russian-Language-Learning-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  